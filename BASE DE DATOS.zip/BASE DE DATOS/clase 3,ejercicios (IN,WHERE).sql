-- A-artículos con precio mayor a 100
select *
from articulos
where precio >= 100;
-- B-artículos con precio entre 20 y 40 (usar < y >)
select *
from articulos
where precio <=20 >=40;
-- C-articulos con precio entre 40 y 60
select *
from articulos
where precio between 40 and 60;
-- D-articulos con precio igual a 20 y stock mayor a 30
select *
from articulos
where precio = 20 and stock <30; 
-- E-articulos con precio 12,20,30 No usar in
select *
from articulos
where precio = (12,20,30);
-- F-articulos con precio 12,20,30 USAR EL IN
select *
from articulos
where precio in (12,20,30);





 







 
