create database Panaderia;
use Panaderia;
create table venta(
        id_venta int,
        fecha_venta datetime,
        id_postre int,
        cantidad_vendida int,
       precio_facturacion_final double);
  drop table venta;
       select *from venta;
        insert into Venta values ('1','2010-04-01','1','100','150'),
                                 ('2','2010-05-02','2','400','433'),
                                 ('4','2010-07-03','5','1200','24000'),
							    ('5','2010-02-05','4','300','125');
                                
       
       
       create table Postre(
       id_postre int,
       nombre varchar(45),
       descripcion varchar(180),
       precio_unitario double
       );
       
      
       insert into Postre values (1,'pasta frola',' tarta artesanal típica de la gastronomía de Argentina','800'),
                                         (1,'pasta frola',' tarta artesanal típica de la gastronomía de Argentina','800'),
                                         (2,'rosca de pascua','tipo de pan dulce tradicional con forma de anillo','700'),
                                         (5,'budin','es un tipo de alimento de la cocina inglesa y estadounidense ','500'),
                                         (4,'pan dulce','variedad de panes cuya masa se elabora con azúcar o algún otro agente edulcorante','200'),
										 (4,'pan dulce','variedad de panes cuya masa se elabora con azúcar o algún otro agente edulcorante','200'),
										(4,'pan dulce','variedad de panes cuya masa se elabora con azúcar o algún otro agente edulcorante','200'),
                                        (5,'budin','es un tipo de alimento de la cocina inglesa y estadounidense ','500'),
                                         (5,'budin','es un tipo de alimento de la cocina inglesa y estadounidense ','500')
                                         ;
       
       select *from Postre;
       /*2- . En su base de datos existe información de las ventas 
       y el área requiere que se liste el id_venta, el precio_facturación_final, 
       y el nombre del postre de todos los postres vendidos cuyo precio_facturacion_final esté entre 80 y 200 pesos (inclusive), 
       ordenado alfabéticamente por nombre del postre. ¡Muchas gracias!
       */
       
        select nombre,precio_facturacion_final,id_venta
from Postre as p
inner join venta as v 
on p.id_postre =v.id_postre
where precio_facturacion_final between 80 and 200
order by nombre;

       
       
       
       
