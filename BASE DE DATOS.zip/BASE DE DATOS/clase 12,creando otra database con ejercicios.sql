-- 1-  Insertar 5 clientes en la tabla clientes utilizando el insert into sin utilizar campos
--  como parte de la sentencias, es decir de la forma simplificada.
use negocio;

select * from clientes;

insert into clientes
values	(
			11,
			'Yamil',
			'Yamilio',
			'Chinalandia 398 caba',
			'103',
            'Yamil@hotmail.com',
			12987654,
			1
		);
        insert into clientes
values	(
			12,
			'Yamil2',
			'Yamilio2',
			'Chinalandia 399 caba',
			'103',
            'Yamil2@hotmail.com',
			12987654,
			1
		);
                insert into clientes
values	(
			13,
			'Yamil3',
			'Yamilio3',
			'Chinalandia 400 caba',
			'103',
            'Yamil3@hotmail.com',
			12987654,
			1
		);
                       insert into clientes
values (
			14,
			'Yamil4',
			'Yamilio4',
			'Chinalandia 401 caba',
			'103',
            'Yamil4@hotmail.com',
			12987654,
			1
		);
                               insert into clientes
values (
			15,
			'Yamil5',
			'Yamilio5',
			'Chinalandia 401 caba',
			'103',
            'Yamil5@hotmail.com',
			12987654,
			1
		);
        
-- 2 Insertar 5 clientes en la tabla clientes utilizando los campos como parte de la sentencias, 
-- es decir de la forma extendida. Completar sólo los campos nombre, apellido y DNI.
select * from clientes;
       insert into clientes (idcliente, nombre, apellido, dni)
values(17,'Yamil A','Yamilio A','23210137') ;
     insert into clientes (idcliente, nombre, apellido, dni)
values(18,'Yamil B','Yamilio B','23210137') ;
     insert into clientes (idcliente, nombre, apellido, dni)
values(19,'Yamil C','Yamilio C','23210137') ;
     insert into clientes (idcliente, nombre, apellido, dni)
values(20,'Yamil D','Yamilio D','23210137') ;
     insert into clientes (idcliente, nombre, apellido, dni)
values(21,'Yamil E','Yamilio E','23210137') ;

-- 3-  Actualizar el nombre del cliente 1 a José.
update 	clientes
set		nombre = 'Jose'
where	idcliente = 1;

