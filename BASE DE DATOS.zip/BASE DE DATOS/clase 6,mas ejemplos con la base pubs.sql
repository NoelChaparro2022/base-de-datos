-- funciones de agregacion
-- listar el precio mas caro de todos los titulos
use pubs;

select max(price) 'precio mas caro papus' from titles;-- 22,95

-- listar el precio mas economico de todos los titulos
select min(price) 'precio mas economico' from titles; -- 2,99

-- listar el precio promedio de todos los titulos
select avg(price) 'precio promedio' from titles;-- 14,76

-- listar el promedio de las horas trabajadas de todos los empleados
select avg(job_lvl) 'promedio de horas' from employee;-- 86,37

-- listar el precio de todos los titulos
select sum(price) 'sumatoria de precios' from titles;-- 236,26

-- listar la cantidad de titulos en la base de datos
select count(title_id) 'cantidad de titulos' from titles;-- 19



-- en un solo SELECT
select max(price) 'precio mas caro'
,min(price) 'precio mas barato'
,avg(price) 'precio promedio'
,count(price) 'cantidad de titulos'
,sum(price) 'sumatoria de precios'
from titles;

-- variantes de COUNT

select* from titles;
select count(title_id) from titles;-- 19
select count(titles);-- 16 -->no nulos
select count(*) from titles;-- 19 ---> nulos y NO nulos

-- agrupaciones
-- sexo,sector,categoria,marca semestre,año
-- listar la cantidad de titulos por categoria

select type categoria
,count(title_id) 'cantidad de titulos por categoria'
from titles
where type not like '%cook%'
group by type
having count(title_id) > 2 -- 
order by 2 desc
limit 2;-- si queres ver los ultimos dos

select type from titles

 