-- subconsultas
use pubs;
-- listar los libros cuyo precio sean inferior al 
-- promedio general de precios.
select	*
from	titles
where	price < (select avg(price) from titles);

-- listar nombre, apellido y fecha de ingreso del
-- primer empleado
select	concat(fname,' ',lname) empleado,
		hire_date 'fecha de ingreso'
from	employee
where	hire_date = (
						select 	min(hire_date)
                        from	employee
					);
                    
-- listar el nombre de los titulos que fueron 
-- publicados en editoriales de USA.
-- por join
select		t.title libro,
			p.pub_name editorial,
			p.country pais
from		titles t
inner join	publishers p
on			p.pub_id = t.pub_id
where		p.country = 'USA';

select * from publishers;

-- por subconsulta
select		t.title libro
from		titles t
where		t.pub_id in (
							select 	pub_id
                            from	publishers 
                            where 	country = 'USA'
						);
-- variante
                        
select		t.title libro
from		titles t
where		exists (
						select 	pub_id
						from	publishers 
						where 	country = 'USA'
					);
                    
-- listar los libros que nunca fueron vendidos
-- por subconsulta
select	title libro
from	titles
where	title_id not in (
							select	title_id
                            from	sales
						);
-- por join
select		t.title libro
			-- ,s.*
from		titles t
left join	sales s
on			s.title_id = t.title_id
where		s.stor_id is null;

-- uso de predicados
create database predicados;

use predicados;

create table productos(nro int, precio double);
create table facturas(nro int, monto double);

insert into productos values
(1,100),(2,200),(3,300),(4,3000);

insert into facturas values
(1,300),(2,600),(3,500),(4,200);

select * from productos;
select * from facturas;

-- listar los productos cuyo precio este por encima de todos los montos
-- facturados
select	*
from	productos
where	precio > all (select monto from facturas);

-- listar los productos cuyo precio este por encima de algun monto
-- facturado
select	*
from	productos
where	precio > any (select monto from facturas);

-- listar los productos cuyo precio sea igual a algun monto
-- facturado
select	*
from	productos
where	precio = any (select monto from facturas);

-- variante
select	*
from	productos
where	precio in (select monto from facturas);

















