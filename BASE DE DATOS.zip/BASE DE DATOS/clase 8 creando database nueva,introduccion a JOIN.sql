create database relaciones;
use relaciones;
create table sucursales (suc_id int, suc_nombre varchar(30));
create table empleados (emp_id int, emp_nombre varchar(30), suc_id int);

insert into sucursales values (1,'Centro'),(2,'Congreso'),(3,'Palermo');
insert into empleados values (1,'Juan',1),(2,'Jose',2),(3,'Carlos',2),(4,'Maria',null);

select* from sucursales;
select* from empleados;



/*
listar los empleados y las sucursales donde trabajan.

*/

select emp_nombre,suc_nombre
from sucursales
inner join empleados -- inner join -- une las tablas que tengan una en comun 
on empleados.suc_id =sucursales.suc_id;

-- o se puede hacer asi para simplificar 


select emp_nombre,suc_nombre
from sucursales as s
inner join empleados as e  
on e.suc_id =s.suc_id;

-- o mas simplificado asi

select e.emp_nombre, s.suc_nombre
from sucursales as s
inner join empleados as e  
on e.suc_id =s.suc_id;

-- o asi mas simplficiado con WHERE

select e.emp_nombre, s.suc_nombre
from sucursales s , empleados e
where e.suc_id =s.suc_id;

-- producto cartesiano con el cross join
select e.emp_nombre, s.suc_nombre
from sucursales s 
cross join empleados e;

-- variante no ANSI
select e.emp_nombre, s.suc_nombre
from sucursales s , empleados e;

-- listar las sucursales donde no trabaja ningun empleado
-- la tabla principal es aquella de la cual quiero obtener datos,cual es la tabla principales entonces? 
-- seria sucursales y la segunda empleados
select s.suc_id
,e.*
from sucursales s left join empleados e
on s.suc_id = e.suc_id;

-- o asi

select s.suc_nombre
,e.*
from empleados e right outer join sucursales s
on s.suc_id = e.suc_id
where e.emp_id is null;

-- listar los empleados que no trabajan en ninguna sucursal -- aca la tabla primera es empleados y la tabla segundaria es sucursal
select e.emp_nombre
,s.*
from empleados e left join sucursales s
on e.suc_id = s.suc_id
where s.suc_id is null;




