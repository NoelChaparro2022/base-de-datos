-- selecciono base por defecto
use pubs;

-- listar el titulo, precio, y categoria de todos los libros cuyo precio. 
-- los libros cuyo precio entre 10 y 20 u$s.
-- ordenar por precio descendente . a igualdad de precios, desempata el titulo en forma alfabetica.
-- no inckuir los libros de cocina.
-- limitar a los 3 primeros titulos

select title as titulo,
       price as precio,
       type as categoria
       from titles  
	   where price between 10 and 20 and type not like '%cook%'
       order by  price desc,title asc   -- asc = alfabetico
       limit 3 ;                      
       
       -- ordernar los empleados por apellido y nombre
       describe employee;
	
       select*
       from employee
       order by fname, lname; -- tambien se puede usar el numero de orden de columna ,en el caso de fname y lname es 4 y 2
       select concat (fname,' ',lname) as empleado,
       job_lvl as 'horas trabajadas en el mes',
       hire_date 'Fecha de Ingreso'
       from employee
       order by 2 desc,1;
       --  like (para listar el apellido con tal letra) y rlike ( con acento)
       -- listar todos los empleados cuyo apellido empiecen con a
        select* from employee where lname like '%a%';
      select* from employee where lname rlike '^a';
      
      -- listar todos los empleados cuyo apellido NO empiece con a
      select* from employee where lname not like 'a%';
      select* from employee where lname rlike '^[^a]';
      
	-- listar los empleados cuyo nombre empiece con m,
    -- el 2do caracter sea cualquiera, el 3er caracter sea r
    -- y no importa como siga
    /*
    Martin,Marcelo,Marina,Miriam,Moria,Mirtha,Maria,Mirko.Muriel,Martina,Mora,Margarita etcetera
*/
select* from employee where fname like 'm_r%';
select* from employee where fname rlike '^m.r.*$'; -- el punto y asterisco (.*) es equivalente al porcentaje

-- listar los empleados que no ingresaron en el año 1990 
select* from employee where not year (hire_date)= 1990;
-- o tambien se puede hacer asi:
select* from employee where hire_date not like '%1990%';
-- o tambien se puede hacer asi:
select* from employee where hire_date rlike '199[^0]';

-- listar los empleados que no ingresaron en el año 1992 ni 1994
select* from employee where hire_date not like '199[^2,4]';
-- empleados que no ingresaron del 1990 a 1993 inclusive
select* from employee where hire_date rlike '199[^0-3]';





       
       
       
       
       
       
       
       
       

       