use pubs;
select * from authors;-- ejercicio 2 Mostrar todos los autores. 

select * from publishers; -- ejercicio 3 Mostrar todas las editoriales. 

select * from stores; -- ejercicio 4 Mostrar la estructura de la tabla STORES. 

select * from sales; -- ejercicio 5 Mostrar la estructura de la tabla SALES.

select fname , lname , hire_date from employee WHERE pub_id = 0877; -- ejercicio 6 Mostrar el código, nombre completo y fecha de ingreso de los empleados que trabajan para la editorial 877. Tener en cuenta que el nombre completo es el resultado de la concatenación del nombre y apellido. Las columnas deben estar apodadas según las siguientes leyendas: "Número de Empleado", "Nombre de Empleado" y "Fecha de Inicio". 

select "titulo" + title, "precio" + price, "precio con iva" + price* 1,21 from titles; -- ejercicio 7 Mostrar el título, precio bruto y precio con IVA de los libros. Ninguna columna debe contener valores nulos. las columnas deben estar apodadas por las siguientes palabras: Título, Precio y Precio lVA. 

select title from titles; -- ejercicio 8 Mostrar los tipos de libros existentes

select distinct country from publishers;-- ejercicio 9 Listar los países de residencia de las editoriales. Evitar las repeticiones. 

select distinct city, state from authors; -- ejercicio 10 Listar las ciudades y estados de residencia de los autores. Evitar las repeticiones.

select fname , lname , hire_date from employee WHERE pub_id = 0877 order by  job_lvl desc,hire_date asc; -- ejercicio 11 Listar todos los empleados de la editorial número 877. Ordenar por nivel de trabajo descendente y por fecha de incorporación ascendente. 

select au_id au_fname, au_lname, phone from authors where state = "CA" and contract= 0;-- ejercicio 12 Listar el número, apellido, nombre y teléfono de los autores que NO tengan contrato y que su estado de residencia sea California (CA). 

select * from employee WHERE year (hire_date)=1990 and job_lvl between 100 and 200;-- ejercicio 13 Listar los empleados cuyo año de incorporación fue 1990 y cuyo nivel  de trabajo esté entre 100 Y 200. 

select * from sales WHERE payterms like '%invoice%' and qty between 13 and 40;
select * from sales where	payterms like '%invoice%' and qty >= 13 and qty <= 40;    -- ejercicio 14 

select pub_id, pub_name from publishers where state is NULL; -- ejercicio 15 Listar número y nombre de las editoriales cuyo estado de residencia contenga valor nulo. 

select title as cocina , price as precio , type as categoria from titles  where type like '%cook%' and title not like 'Sushi%'order by  price desc; -- ejercicio 16 Listar el título y precio de los libros de cocina cuyo título no figure la palabra "sushi". Ordenar por precio descendente

 select* from employee where fname like '%p_o%';-- ejercicio 17 Listar todos los empleados cuyo nombre empiece con la letra P y termine con la letra O, y su apellido termine con la letra O. 	
 
 
