create database AreaAdministrativa;
use AreaAdministrativa;
create table Empleado(
       id_empleado int,
       apellido varchar(45),
       nombre varchar(45),
       horas_trabajadas int,
       fecha_ingreso datetime,
      id_cargo int
          );
      
          select*from empleado;
          insert into Empleado values ('1','Suarez ','Yamil ',' 140','2022-05-01','2'),
           ('2','Basualdo','Agustin ',' 160','2021-05-11','3'),
            ('3','Suarez ','Allen',' 180','2022-07-14','3'),
             ('4','Martin','Lucas',' 140','2020-08-18','2'),
              ('5','Skywalker','Nolan',' 130','2018-02-23','1'),
               ('6','Perez','Henry',' 140','2014-03-20','1'),
                ('7','Hicks','Dwayne',' 140','2002-05-16','1'),
                 ('8','Sgt','Candy',' 120','2023-07-19','2'),
                  ('9','Ñuflow','Veronica ',' 120','2017-09-05','3'),
                   ('10','Cheng','Elizabeth',' 110','2005-12-03','1'),
           ('11','Cheng','Clark',' 110','2005-12-03','23'),
            ('12','Hudson','Alejandro',' 160','2013-12-03','25'),
            ('13','Ripley','Hellen',' 170','2020-11-02','26'),
             ('14','Dent','Jack',' 180','2015-03-13','27'),
              ('15','Gordon','Cole',' 130','2006-03-18','22'),
               ('16','Swayne','Taylor',' 110','2017-09-10','21'),
                    ('17','West','Wally',' 120','2017-06-10','15')
          
           ;
         
          
          
          
          
          
          
          create table Cargo(
          id_cargo int,
          descripcion varchar (180),
          valor_hora int,
          valor_hora_extra int
          );
          insert into Cargo values ('2','empleado con cargo de oficinista','80','40'),
          ('3','empleado con cargo de Supervisor','90','50'),
          ('3','empleado con cargo de Supervisor','90','50'),
          ('2','empleado con cargo de oficinista','80','40'),
          ('1','empleado con cargo de directiva','190','100'),
          ('1','empleado con cargo de directiva','190','100'),
          ('1','empleado con cargo de directiva','190','100'),
          ('2','empleado con cargo de oficinista','80','40'),
          ('3','empleado con cargo de Supervisor','90','50'),
          ('1','empleado con cargo de directiva','190','100'),
          ('23','empleado con cargo de Envios','20','15'),
          ('25','empleado con cargo de Diseño','130','115'),
          ('26','empleado con cargo de alinear','40','20'),
          ('27','empleado con cargo de instructor','50','25'),
           ('22','empleado con cargo de jefatura','120','60'),
           ('21','empleado con cargo de promocion','15','5'),
            ('19','empleado con cargo de promocion extranjera','30','15')
          
          ;
          
      
select*from cargo;

/*3-
el area administrativa esta generando los recibos de sueldo
para eso requiere que listes el id_empleado ,valor_hora,valor_hora_extras de todos los empleados 
que pertenezcan a los cargos 1 al 5 y 20 al 28
*/


select concat(nombre,'  ',apellido)empleado,e.id_cargo,id_empleado,valor_hora,valor_hora_extra
from Cargo as c
inner join empleado as e
on c.id_cargo= e.id_cargo
where  C.id_cargo between 1 and 5 or E.id_cargo between 20 and 28;
-- o se puede usar el in asi   =     where e.id_cargo in   (1,2,3,4,5,20,21,22,23,24,25,26,27,28)

;
