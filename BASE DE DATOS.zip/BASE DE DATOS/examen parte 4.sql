create database Administracion;
USE ADMINISTRACION;

drop database administracion;
CREATE TABLE cliente (
  id int NOT NULL  AUTO_INCREMENT  , -- no pude usar el IDENTITY porque mi servidor de SQL no lo detecta por alguna razon
  nombre VARCHAR(255) NOT NULL,
  PRIMARY KEY (id)
);

drop table cliente;

 insert into cliente values('2','Juan'),
 ('4','Yamil'),
  ('6','Alejandro'),
   ('8','Ariel'),
    ('10','Melisa')
 ;
 
 
 select*from cliente;
 
CREATE TABLE pedido (
  id int NOT NULL AUTO_INCREMENT,
  id_cliente int NOT NULL,-- aca tambien no pude usar el identity
  comentario text NOT NULL,
  fecha datetime NOT NULL,
  FOREIGN KEY (id_cliente) REFERENCES cliente(id),
  PRIMARY KEY (id)
);

select * from pedido;
 insert into pedido values
 ('1','2','pedido de:pizza','2021-05-11'),
 ('2','4','pedido de:alitas de pollo','2021-05-11'),
 ('3','10','pedido de:lentejas','2021-03-15'),
 ('4','8','pedido de:empanadas','2022-10-01'),
 ('5','10','pedido de:Hamburguesas','2022-07-14');
 
-- a)	Crear una consulta que busque todos los pedidos del mes actual, 
-- trayendo la fecha y el comentario del pedido y el nombre del cliente.
select nombre,comentario,fecha
from cliente as c
inner join pedido as p 
on p.id =c.id
where month  (current_date())=month(p.fecha);
-- b)	Crear una consulta que devuelva la cantidad de pedidos por mes que hizo cada cliente,
--  ordenando el resultado por mes y luego por nombre de cliente.
select  nombre ,p.id as pedidos,id_cliente ,fecha 
from cliente as c
right join pedido as p
on c.id=p.id
where p.id < (select avg(fecha) from pedido)

order by nombre;
-- c)	Crear una consulta que devuelva todos los clientes que tienen más de 10 pedidos, 
 -- ordenando el resultado por cantidad de pedidos. 
select     nombre, p.id_cliente, p.comentario
from        Cliente c
cross join  Pedido p 
on          p.id = c.id
where       p.id <= 10
order by    p.id desc;
