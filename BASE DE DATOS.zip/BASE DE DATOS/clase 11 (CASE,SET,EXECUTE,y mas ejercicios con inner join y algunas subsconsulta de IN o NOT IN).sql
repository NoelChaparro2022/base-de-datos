use pubs;

-- 41.	Listar el nombre de los libros junto a su categoría de precio. 
-- La categoría de precio se calcula de la siguiente manera: 
-- Si el precio está entre 0 y 10 la categoría es Económica. 
-- Si la categoría está entre 10 Y 20, Normal y si su valor es mayor a 20 la categoría es Caro.
--  Colocar un apodo a las dos columnas.        (ACA SE USA EL CASE Y WHEN)
select title titulo,
(case -- equivalente al Switch en java
when price < 10 then 'Economica' -- como poner precio menor o mayor a tal numero
when price between 10 and 20 then 'normal' -- como poner precio entre tal y tal nro
when price > 20 then 'cara' 
else 'No categorizado0' -- equivalente al Default en Java
end) as categoria
from titles;

-- 42. Listar los 5 libros más caros. 

select title as titulo, -- libros
price as precio-- precio
from titles
order by price desc -- precio descendente (osea mas caro)
limit 5; -- 5 libros mas caros

-- 43. Listar la mitad de los empleados.  (SE USA SET Y PREPARE Y EXECUTE)

SET @inicio=0; -- variable de inicio 
SET @cantidadRegistros=(select (count(*) div 2 + 1) from employee); -- asi se saca la mitad de los empleados
PREPARE sentencia FROM 'SELECT * FROM employee LIMIT? , ?' ; -- Preparo sentencia para limitar las variables anteriores
EXECUTE sentencia USING @inicio,@cantidadRegistros; -- ejecuto la sentencia anterior


-- 44.	Listar todos los libros vendidos, su nombre y la cantidad vendida por cada uno. 
-- Los apodos para las columnas son las siguientes: "Código del libro", "Nombre del libro" y "Cantidad vendida" .



select  t.title as 'codigo de libro',
t.title as 'nombre del libro',
s.qty 'cantidad vendida' -- sum qty para saber la cantidad vendida de cada uno 
from titles t
inner join sales s  
on s.title_id =t.title_id; -- e inner join con sales para ver cuantos se vendieron


-- 45.	Listar todos los libros cuyo precio sea inferior al precio promedio de todos los libros. 

select *
from titles 
where price < (select avg(price) from titles); -- calculo de precio inferior de Precio PROMEDIO de todos los libros

-- 46 Listar los empleados de aquellas editoriales que residan en USA. No usar relaciones para su resolución. 
select*
from employee
where pub_id in  -- subconsulta
(select pub_id from publishers where country = 'USA');  -- ASI SE HACE POR SUBSCONSULTA Y SIN JOINS

-- POR JOIN SE HARIA ASI=

select e.*
from employee e
inner join publishers p
on e.pub_id = p.pub_id
where p.country = 'USA';

-- 47 	Listar la cantidad de libros vendidos por cada tienda, 
-- sólo de aquellas tiendas que su cantidad de venta sea mayor al promedio de venta general. 



select st.stor_name tienda, 
sum(s.qty) 'ventas x por tienda' -- cantidad de libros vendidos por cada tienda
from stores st
inner join sales s
on st.stor_id = s.stor_id
group by st.stor_name
-- y para sumar la cantidad de ventas en general
having sum(s.qty) > (select sum(qty)/count(distinct(stor_id)) from sales);--  tiene que dar los menores a 58



-- 48.	Listar todos los comprobantes de ventas emitidos para la venta del libro "Sushi, Anyone?".
--  No utilizar relaciones. 

select ord_num as 'comprobante de venta' 
from sales s
inner join titles t
on t.title_id = s.title_id
where t.title = "Sushi, Anyone?";

-- por subconsulta

select ord_num as 'comprobante de venta'
from sales where title_id in (select title_id 
from titles where title = "Sushi, Anyone?");


-- 49.	Mostrar el nombre de los libros junto a su categoría de precio 
-- de aquellos libros que son categorizado como "Normal".
 -- La categoría de los precios es la misma del ejercicio 41. 
 select * 
 from (
 select title libro,
(case 
when price < 10 then 'Economica' 
when price between 10 and 20 then 'normal' 
when price > 20 then 'cara' 
else 'No categorizado' 
end) as categoria
from titles)
as misubconsulta where misubconsulta.categoria = 'normal';

-- 50 Listar título del libro, categoría de precio, precio unitario y 
-- cantidad ejemplares vendidos. Mostrar sólo aquellos libros que sean económicos 
-- y cuya cantidad de ejemplares vendidos sea mayor a cero. 
-- Se deben apodar las columnas de la siguiente manera: 'Tít", "Cat", "Pr", "Cant".
--  La categoría de los precios es la misma del ejercicio 41.

 select * 
 from (
 select title libro,
 qty ventas,
(case 
when price < 10 then 'Economica' 
when price between 10 and 20 then 'normal' 
when price > 20 then 'cara' 
else 'No categorizado' 
end) as categoria
from titles t
inner join sales s on t.title_id = s.title_id
where s.qty > 0
)
as misubconsulta where misubconsulta.categoria = 'normal';
