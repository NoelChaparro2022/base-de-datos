/* esto es un comentario 
*/
/*--selecciono una base de datos por defecto*/
use negocio;
 
 /*--veo las tablas de la base seleccionada*/
 show tables;
 
 -- veo la estructura de la tabla clientes 
 
 
 -- queries
 -- listar todos los datos (camapos) de la tabla clientes
 select *from negocio.clientes;
 
 -- listar nombre,apellido y email de todos los cliente

select nombre,
apellido,
email
from clientes;

-- listar articulo,precio y stock de todos los productos
select articulo,
precio,
stock
from productos;

-- uso de comlumnas agregadas y calculadas

select 'HOY ES MARTES' as comentario -- uso de alias de columna 
,articulo
,concat('$',precio) as precio
,precio
,truncate(precio * 1.21, 0) as 'precio con IVA'
,stock
,now() as 'fecha de consulta'
from productos

-- filtro de registros
-- listar los productos cuyo precio sean mayores a 100 $

/*operadores aritmeticos: + - 
operadores relacionales: > < > >= <=  = != <>
operadores logicos: and or not

indicar el precio entre 100 y 200
*/

select *
from productos
where precio >= 100 and precio <= 200;

/* tambien se puede usar asi */
select *
from productos
where precio between 100 and 200;-- between incluye extremos papanatas


select*
from productos
where precio not between 100 and 200;-- not between NO incluye extremos papanaTe

-- listar los empleados que ingresaron en 1990

select *
from pubs.employee
where hire_date between '1990-01-01' and '1990-12-31';


/*o tambien asi*/

select*
from pubs.employee
where year(hire_date) = 1990 and month(hire_date) = 6;

-- operador de lista insert
-- listar todos los titulos de negocios o cocina}

select * 
from pubs.titles
where type = 'business' or type like '%cook%';

/*porcentaje (%) es un patron de busqueda --> desde 0 hasta N caracteres*/

select * 
from pubs.titles
where type in ('business' , 'trad_cook', 'mod_cook');










