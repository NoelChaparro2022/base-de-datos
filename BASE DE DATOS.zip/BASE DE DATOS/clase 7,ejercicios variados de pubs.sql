-- 21. Contar la cantidad de autores que su estado de residencia sea California (CA). Poner un apodo al nombre de columna. 
use pubs;
select count(au_id) as ' cantidad de autores' from authors where state = "CA" ;

-- 22. Mostrar la fecha de inicio de facturación y el último número de comprobante emitido. Poner un apodo a cada columna

select min(ord_date) as 'fecha de inicio de facturacion',  max(ord_num) 'ultimo numero de comprobante emitido' from sales;

-- 23.  Contar la cantidad de países que residen alguna editorial. 

select country  as 'cantidad de paises que residen editorial' from publishers;

-- o asi se hace tambien (forma correcta)
select count(distinct country) as 'cantidad de paises que residen editorial' from publishers;
-- forma final asi=
select distinct country as 'cantidad de paises que residen editorial' from publishers;


-- 24 Listar las categorías de libros y el valor promedio para cada tipo de libro. 

select type categoria,avg(price)  'precio promedio de categoria' from titles group by type;
--   (ejercicio que yo hice=)
select type as categoria  ,round(avg (price),2) as 'precio promedio de categoria' from titles group by type;

-- 25 ldem ejercicio 24 pero no incluir dentro de la lista los libros que no tienen decidida una categoría. 

select type as'sin categoria',avg(price)  'precio promedio de categoria' from titles where type is not null group by type;

-- oo asi se puede hacer tambien
select type as'sin categoria',avg(price)  'precio promedio de categoria' from titles where type <> '' group by type;



-- 26  Listar los locales que hayan vendido más de 100 libros. 

select stor_id tienda,
sum(qty) as 'ventas x tienda'
 from sales
 group by stor_id
 having  sum(qty) >100;


-- 27. Listar la cantidad de ejemplares vendidos de cada libro en cada tienda. Poner apodos a las columnas. 

select stor_id tienda,
title_id titulo,
sum(qty) ventas
from sales
group by stor_Id, title_id
order by 1;


