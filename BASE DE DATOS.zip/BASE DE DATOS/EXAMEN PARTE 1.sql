create database CasaDeEmpanadas;
use CasaDeEmpanadas;
create table Venta(
        id_venta int,
        fecha_venta datetime,
        id_tipo_empanada int,
        cantidad_vendida int,
       precio_facturacion_final double);

        insert into Venta values ('1','2010-05-01','1','1500','30000'),
                                 ('2','2010-06-02','2','1400','28000'),
                                 ('4','2010-06-03','5','200','4000'),
							    ('5','2010-08-05','4','1300','26000');
                                
       
       
       create table TipoEmpanada(
       id_tipo_empanada int,
       nombre varchar(45),
       id_gusto int,
       descripcion varchar(180)
       );
       
      
       insert into tipoempanada values (1,'Jamon y queso','2','Salteña'),
                                         (1,'Jamon y queso','2','Salteña'),
                                         (2,'Carne','1','Jujeña'),
                                         (5,'Atun','3','tucumana'),
                                         (4,'Choclo','4','Catamarqueña'),
										 (4,'Choclo','4','Catamarqueña'),
										(4,'Choclo','4','Catamarqueña'),
                                        (5,'Jamon y queso','2','Catamarqueña'),
                                         (5,'Jamon y queso','2','Catamarqueña')
                                         ;
       
       
       /* 1- consulta de empanadas listando id_venta, el precio_facturacion_ final,
       y el tipo de empanada de todas las empanadas vendidas
        con la cantidad vendida entre 1000 y 2000 unidades,
        ordenado alfabéticamente por tipo de empanada (nombre)=
       */
       
 select nombre,id_gusto,descripcion,precio_facturacion_final,id_venta
from tipoempanada as t
inner join venta as v  
on v.id_tipo_empanada =t.id_tipo_empanada
where cantidad_vendida between 1000 and 2000
order by nombre;





